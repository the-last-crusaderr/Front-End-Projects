# Portfolio Project

This is the source code for my portfolio website. I built this to showcase what I've been working on.

## Built with

* HTML
* CSS
* [Font Awesome](https://fontawesome.com/)

## Demo

You can visit the website by going [here](https://priceless-kepler-06d70c.netlify.app/).
